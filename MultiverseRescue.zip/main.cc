#include <iostream>
#include "Robot.h"
using namespace std;


const string BUTTON = "button";
const string LEFT = "left";
const string RIGHT = "right";
const string QUIT = "quit";


class Quit {
	string msg = "You have quit the game.";
public:
	Quit();
	string getMsg() const;
};


Quit::Quit() {}


string Quit::getMsg() const {
	return msg;
}


Robot configureRobot() {
	Robot r;
	int numPlayers = 0;
	while (numPlayers < 1) {
		cout << "Enter the number of players playing this game.";
		cout << endl;
		cin >> numPlayers;
		if (numPlayers < 1) {
			cout << "Please enter at least 1 player." << endl;
		}
	}
	string name = "";
	int i = 0;
	bool taken = false;
	while (i < numPlayers) {
		cout << "Enter the name of player " << i << "." << endl;
		cin >> name;
		for (unsigned int j = 0; j < r.getPlayers().size(); ++j) {
			if (r.getPlayers()[j] == name) {
				cout << "This name has been taken." << endl;
				taken = true;
				break;
			}
		}
		if (taken) {
			taken = false;
		} else {
			r.addPlayer(name);
			++i;
		}
	}
	return r;
}


void intro() {
	cout << "One day at the lab, a malfunction sent you all to ";
	cout << "separate pocket dimensions in the Multiverse!" << endl;
	cout << "Fortunately, you have a partially-finished, experimental ";
	cout << "robot at your disposal to help you ";
	cout << "get back home, if you can figure out how it works." << endl;
	cout << "The engineers tell you, over interdimensional radio, ";
	cout << "that the robot has 2 levers (each with 2 positions A and B) ";
	cout << "and a button." << endl;
	cout << "Once the engineers press the button, ";
	cout << "the robot will teleport into ";
	cout << "a random dimension. The person in that dimension must then ";
	cout << "either move exactly 1 lever from A to B, or vice versa, ";
	cout << "or press the button, and nothing else." << endl;
	cout << "Once that person flips a lever, the robot will randomly ";
	cout << "teleport into any dimension (including the dimension just ";
	cout << "visited). The robot will only visit the dimensions you are ";
	cout << "trapped in." << endl;
	cout << "Once anyone presses the button again, the robot will then ";
	cout << "teleport everyone that has flipped a lever back home!";
	cout << endl;
	cout << "Anyone that has not pulled a lever when the button is ";
	cout << "pressed will be lost in the Multiverse forever!" << endl;
	cout << "Your goal is to ensure that everyone makes it home." << endl;
	cout << "You may discuss your strategy now, but ";
	cout << "once the robot enters your dimensions, it will interfere ";
	cout << "with all attempts at communication via interdimensional ";
	cout << "radio." << endl;
	string proceed = "";
	cout << "Enter '" << QUIT << "' to quit." << endl;
	cout << "Enter any non-whitespace character(s) when you are ready ";
	cout << "to proceed." << endl;
	cin >> proceed;
	if (proceed == QUIT) {
		throw Quit{};
	}
	return;
}


int main() {
try {
	Robot r = configureRobot();
	intro();
	r.teleport();
	while (true) {
		cout << "ROBOT AT ARRIVAL:" << endl;
		cout << r;
		cout << "Please enter one of the following commands:" << endl;
		cout << LEFT << ": flip the left lever" << endl;
		cout << RIGHT << ": flip the right lever" << endl;
		cout << BUTTON << ": press the button" << endl;
		string cmd = "";
		cin >> cmd;
		if (cmd == LEFT) {
			r.flipLeft();
			cout << "ROBOT AT DEPARTURE:" << endl;
			cout << r;
			r.teleport();
		} else if (cmd == RIGHT) {
			r.flipRight();
			cout << "ROBOT AT DEPARTURE:" << endl;
			cout << r;
			r.teleport();
		} else if (cmd == BUTTON) {
			r.pressButton();
			break;
		} else if (cmd == QUIT) {
			throw Quit{};
		} else {
			cout << "Invalid Command" << endl;
		}
	}
} catch (Quit &q) {
	cout << q.getMsg() << endl;
	return 0;
}
	return 0;
}
