#include <cstdlib>
#include <ctime>
#include "Robot.h"
using namespace std;


Robot::Robot() {
	srand(time(NULL));
}


vector<string> Robot::getPlayers() const {
	return players;
}


void Robot::addPlayer(string &name) {
	players.emplace_back(name);
	leverPulled.emplace_back(false);
	return;
}


int Robot::getLocation() const {
	return location;
}


void Robot::teleport() {
	location = rand() % players.size();
	return;
}


char Robot::getLeft() const {
	return leftLever;
}


char Robot::getRight() const {
	return rightLever;
}


void Robot::flipLeft() {
	if (leftLever == 'A') {
		leftLever = 'B';
	} else if (leftLever == 'B') {
		leftLever = 'A';
	}
	leverPulled[location] = true;
	return;
}


void Robot::flipRight() {
	if (rightLever == 'A') {
		rightLever = 'B';
	} else if (rightLever == 'B') {
		rightLever = 'A';
	}
	leverPulled[location] = true;
	return;
}


void Robot::pressButton() const {
	cout << players[location] << " has pressed the button!" << endl;
	cout << "The following players have been teleported home:" << endl;
	for (unsigned int i = 0; i < players.size(); ++i) {
		if (leverPulled[i]) {
			cout << players[i] << endl;
		}
	}
	cout << "The following players are stuck in the Multiverse forever:";
	cout << endl;
	for (unsigned int i = 0; i < players.size(); ++i) {
		if (!leverPulled[i]) {
			cout << players[i] << endl;
		}
	}
	bool success = true;
	for (unsigned int i = 0; i < leverPulled.size(); ++i) {
		if (!leverPulled[i]) {
			success = false;
			break;
		}
	}
	if (success) {
		cout << "CONGRATULATIONS! Everyone made it home!" << endl;
	} else {
		cout << "OH NO! At least 1 person is stuck in the ";
		cout << "Multiverse forever!" << endl;
	}
	return;
}


ostream &operator<<(ostream &out, const Robot &r) {
	out << "ROBOT:" << endl;
	out << "CURRENT PLAYER: " << r.getPlayers()[r.getLocation()] << endl;
	out << "LEFT LEVER POSITION: " << r.getLeft() << endl;
	out << "RIGHT LEVER POSITION: " << r.getRight() << endl;
	return out;
}
