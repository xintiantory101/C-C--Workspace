#ifndef ROBOT_H
#define ROBOT_H


#include <iostream>
#include <string>
#include <vector>


class Robot {
	std::vector<std::string> players;
	std::vector<bool> leverPulled;
	int location;
	char leftLever = 'A';
	char rightLever = 'A';
public:
	Robot();
	std::vector<std::string> getPlayers() const;
	void addPlayer(std::string &name);
	int getLocation() const;
	void teleport();
	char getLeft() const;
	char getRight() const;
	void flipLeft();
	void flipRight();
	void pressButton() const;
};


std::ostream &operator<<(std::ostream &out, const Robot &r);


#endif
