#include <assert.h>
#include "inexact.h"


// my_abs(n) returns the absolute value of n.
// time: O(1)

static float my_abs(float n) {
  if (n > 0) {
    return n;
  } else {
    return -n;
  }
}


bool check_within(float val1, float val2, float err) {
  assert(err >= 0);
  return my_abs(val2 - val1) <= err;
}