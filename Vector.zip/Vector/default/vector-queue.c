#include <assert.h>
#include <stdlib.h>
#include "vector-queue.h"


struct vector *vector_create(void) {
  struct vector *v = malloc(sizeof(struct vector));
  v->len = 0;
  v->maxlen = 1;
  v->data = malloc(v->maxlen * sizeof(float));
  return v;
}


bool vector_is_empty(const struct vector *v) {
  assert(v);
  return (v->len == 0);
}


void vector_add_back(float item, struct vector *v) {
  assert(v);
  if (v->len == v->maxlen) {
    v->maxlen *= 2;
    v->data = realloc(v->data, v->maxlen * sizeof(float));
  }
  v->data[v->len] = item;
  ++(v->len);
  return;
}


float vector_front(const struct vector *v) {
  assert(v);
  assert(v->len > 0);
  return v->data[v->len - 1];
}


float vector_remove_front(struct vector *v) {
  assert(v);
  --(v->len);
  if (v->len * 4 == v->maxlen) {
    v->maxlen /= 2;
    v->data = realloc(v->data, v->maxlen * sizeof(float));
  }
  return v->data[v->len];
}


void vector_destroy(struct vector *v) {
  assert(v);
  free(v->data);
  v->data = NULL;
  free(v);
  v = NULL;
  return;
}