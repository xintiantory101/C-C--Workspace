// Vector Float Queue ADT


#include <stdbool.h>


struct vector {
  float *data;
  int len;
  int maxlen;
};


// vector_create() creates a new vector.
// effects: allocates memory (must call vector_destroy to free)
// time: O(1)

struct vector *vector_create(void);


// vector_is_empty(v) determines if v is empty.
// requires: v is not NULL
// time: O(1)

bool vector_is_empty(const struct vector *v);


// vector_add_back(item, v) adds item to the back of v.
// requires: v is not NULL
// effects: modifies v
// time: O(1)

void vector_add_back(float item, struct vector *v);


// vector_front(v) returns the front value of v.
// requires: v is not NULL and not empty
// time: O(1)

float vector_front(const struct vector *v);


// vector_remove_front(v) removes and returns the front value of v.
// requires: v is not NULL and not empty
// time: O(n), n = v->len

float vector_remove_front(struct vector *v);


// vector_destroy(v) frees v.
// requires: v is not NULL
// effects: v is no longer valid
// time: O(1)

void vector_destroy(struct vector *v);