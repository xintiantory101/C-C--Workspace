#include <stdio.h>
#include "inexact.h"
#include "vector.h"

int main(void) {
  struct vector *v1 = vector_create();
  struct vector *v2 = vector_create();
  vector_add_back(0, v1);
  vector_add_back(0, v1);
  vector_add_back(2, v2);
  vector_add_back(-3, v2);
  printf("%f\n", dot_product(v1, v2));
  printf("%d\n", orthogonal(v1, v2));
  printf("%f\n", norm(v2));
  printf("%f\n", norm(v1));
  vector_destroy(v1);
  vector_destroy(v2);
	return 0;
}
