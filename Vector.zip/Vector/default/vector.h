// Vector ADT


#include <stdbool.h>
#include "inexact.h"
#include "vector-queue.h"


// vector_euclidean_space(v) determines the Euclidean Space of v.
// requires: v is not NULL
// time: O(1)

int vector_euclidean_space(const struct vector *v);


// zero_vector(v) determines if v is the zero vector.
// requires: v is not NULL
// time: O(n), n = v->len

bool zero_vector(const struct vector *v);


// vector_equal(v1, v2) determines if v1 and v2 are equal.
// requires: v1 and v2 are not NULL
// time: O(1)

bool vector_equal(const struct vector *v1, const struct vector *v2);


// vector_add(v1, v2) adds v1 and v2.
// requires: v1 and v2 have the same Euclidean Space and are not NULL.
// effects: allocates memory (must call vector_destroy to free)
// time: O(n), n = Euclidean Space of v1

struct vector *vector_add(const struct vector *v1, const struct vector *v2);


// vector_scalar_mult(c, v1) multiplies v1 by c.
// requires: v1 is not NULL
// effects: allocates memory (must call vector_destroy to free)
// time: O(n), n = Euclidean Space of v1

struct vector *vector_scalar_mult(float c, const struct vector *v1);


// dot_product(v1, v2) returns the dot product of v1 and v2.
// requires: v1 and v2 have the same Euclidean Space and are not NULL
// time: O(n), n = Euclidean Space of v1

float dot_product(const struct vector *v1, const struct vector *v2);


// cross_product(v1, v2) returns the cross product of v1 and v2.
// requires: v1 and v2 are not NULL and each have a Euclidean Space of R3
// time: O(1)

struct vector *cross_product(const struct vector *v1, 
                             const struct vector *v2);


// orthogonal(v1, v2) determines if v1 and v2 are orthogonal.
// requires: v1 and v2 have the same Euclidean Space and are not NULL
// time: O(n), n = Euclidean Space of v1

bool orthogonal(const struct vector *v1, const struct vector *v2);


// norm(v) returns the norm of v.
// requires: v is not NULL
// time: O(n), n = Euclidean Space of v

float norm(const struct vector *v);


// proj(v1, v2) returns the projection of v1 onto v2.
// requires: v1 and v2 have the same Euclidean Space and are not NULL
// effects: allocates memory (must call vector_destroy to free)
// time: O(n), n = Euclidean Space of v1

struct vector *proj(const struct vector *v1, const struct vector *v2);


// perp(v1, v2) returns the perpendicular of v1 onto v2.
// requires: v1 and v2 have the same Euclidean Space and are not NULL
// effects: allocates memory (must call vector_destroy to free)
// time: O(n), n = Euclidean Space of v2

struct vector *perp(const struct vector *v1, const struct vector *v2);