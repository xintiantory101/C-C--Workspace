#include <assert.h>
#include <math.h>
#include "vector.h"


int vector_euclidean_space(const struct vector *v) {
  assert(v);
  return v->len;
}


bool zero_vector(const struct vector *v) {
  assert(v);
  for (int i = 0; i < v->len; ++i) {
    if (!check_within(v->data[i], 0, 0.001)) {
      return false;
    }
  }
  return true;
}


bool vector_equal(const struct vector *v1, const struct vector *v2) {
  assert(v1);
  assert(v2);
  if (v1->len != v2->len) {
    return false;
  }
  for (int i = 0; i < v1->len; ++i) {
    if (!check_within(v1->data[i], v2->data[i], 0.001)) {
      return false;
    }
  }
  return true;
}


struct vector *vector_add(const struct vector *v1, const struct vector *v2) {
  assert(v1);
  assert(v2);
  assert(v1->len == v2->len);
  struct vector *v = vector_create();
  for (int i = 0; i < v1->len; ++i) {
    v->data[i] = v1->data[i] + v2->data[i];
  }
  return v;
}


struct vector *vector_scalar_mult(float c, const struct vector *v1) {
  assert(v1);
  struct vector *v = vector_create();
  for (int i = 0; i < v1->len; ++i) {
    v->data[i] = c * v1->data[i];
  }
  return v;
}


float dot_product(const struct vector *v1, const struct vector *v2) {
  assert(v1);
  assert(v2);
  assert(v1->len == v2->len);
  float dp = 0;
  for (int i = 0; i < v1->len; ++i) {
    dp += (v1->data[i] * v2->data[i]);
  }
  return dp;
}


struct vector *cross_product(const struct vector *v1, 
                              const struct vector *v2) {
  assert(v1);
  assert(v2);
  assert(v1->len == 3);
  assert(v2->len == 3);
  struct vector *v = vector_create();
  vector_add_back(v1->data[1] * v2->data[2] - v1->data[2] * v2->data[1], v);
  vector_add_back(v1->data[2] * v2->data[0] - v1->data[0] * v2->data[2], v);
  vector_add_back(v1->data[0] * v2->data[1] - v1->data[1] * v2->data[0], v);
  return v;
}


bool orthogonal(const struct vector *v1, const struct vector *v2) {
  assert(v1);
  assert(v2);
  assert(v1->len == v2->len);
  return (dot_product(v1, v2) == 0);
}


float norm(const struct vector *v) {
  return sqrt(dot_product(v, v));
}


struct vector *proj(const struct vector *v1, const struct vector *v2) {
  assert(v1);
  assert(v2);
  assert(v1->len == v2->len);
  const int c = dot_product(v1, v2) / (norm(v2) * norm(v2));
  struct vector *v = vector_scalar_mult(c, v2);
  return v;
}


struct vector *perp(const struct vector *v1, const struct vector *v2) {
  assert(v1);
  assert(v2);
  assert(v1->len == v2->len);
  struct vector *v = vector_add(v1, vector_scalar_mult(-1, proj(v1, v2)));
  return v;
}