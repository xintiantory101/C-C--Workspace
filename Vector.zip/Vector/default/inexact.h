// Inexact Number ADT


#include <stdbool.h>


// check_within(val1, val2, err) determines if val1 and val2 are no more than 
//   err apart.
// requires: err >= 0
// time: O(1)

bool check_within(float val1, float val2, float err);