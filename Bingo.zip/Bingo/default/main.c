// This program runs a standard game of BINGO!


#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


struct board {
  int col_B[5];
  int col_I[5];
  int col_N[5];
  int col_G[5];
  int col_O[5];
};


struct game {
  int num_of_players;
  struct board *boards;
  bool *bingo;
};


// number_of_players() gets the number of players.
// effects: reads input

int number_of_players(void) {
  int pw = 0;
  int num = 0;
  while (true) {
    printf("Enter the number of players you wish to play.\n");
    printf("Note that there must be at least 1 player.\n");
    pw = scanf("%d", &num);
    if (num > 0 || pw != 1) {
      break;
    }
  }
  return num;
}


// initialize_game(num_of_players) initializes the game according to 
//   the number of players num_of_players.
// requires: num_of_players > 0
// effects: allocates memory (must call destroy_game to free)

struct game *initialize_game(int num_of_players) {
  assert(num_of_players > 0);
  struct game *game = malloc(sizeof(struct game));
  game->num_of_players = num_of_players;
  game->boards = malloc(num_of_players * sizeof(struct board));
  game->bingo = malloc(num_of_players * sizeof(bool));
  return game;
}


// initialize_boards(game) initializes the boards in the game.
// requires: game is not NULL
// effects: modifies game
//          prints output

void initialize_boards(struct game *game) {
  assert(game);
  printf("Welcome to BINGO!\n");
  for (int i = 0; i < game->num_of_players; ++i) {
    printf("Player %d:\n", i + 1);
    for (int j = 0; j < 5; ++j) {
      int pw = 0;
      int num = 0;
      bool dup = false;
      while (true) {
        printf("Enter a number between 1 and 15 ");
        printf("to place in row %d, column B.\n", j + 1);
        printf("Note that all numbers must be unique.\n");
        pw = scanf("%d", &num);
        for (int k = 0; k < 5; ++k) {
          if (game->boards[i].col_B[k] == num) {
            dup = true;
          }
        }
        if (num >= 1 && num <= 15 && !dup) {
          break;
        }
        printf("Invalid Entry\n");
        dup = false;
      }
      game->boards[i].col_B[j] = num;
    }
    for (int j = 0; j < 5; ++j) {
      int pw = 0;
      int num = 0;
      bool dup = false;
      while (true) {
        printf("Enter a number between 16 and 30 ");
        printf("to place in row %d, column I.\n", j + 1);
        printf("Note that all numbers must be unique.\n");
        pw = scanf("%d", &num);
        for (int k = 0; k < 5; ++k) {
          if (game->boards[i].col_I[k] == num) {
            dup = true;
          }
        }
        if (num >= 16 && num <= 30 && !dup) {
          break;
        }
        printf("Invalid Entry\n");
        dup = false;
      }
      game->boards[i].col_I[j] = num;
    }
    for (int j = 0; j < 5; ++j) {
      int pw = 0;
      int num = 0;
      bool dup = false;
      while (true) {
        printf("Enter a number between 31 and 45 ");
        printf("to place in row %d, column N.\n", j + 1);
        printf("Note that all numbers must be unique.\n");
        pw = scanf("%d", &num);
        for (int k = 0; k < 5; ++k) {
          if (game->boards[i].col_N[k] == num) {
            dup = true;
          }
        }
        if (num >= 31 && num <= 45 && !dup) {
          break;
        }
        printf("Invalid Entry\n");
        dup = false;
      }
      game->boards[i].col_N[j] = num;
    }
    for (int j = 0; j < 5; ++j) {
      int pw = 0;
      int num = 0;
      bool dup = false;
      while (true) {
        printf("Enter a number between 46 and 60 ");
        printf("to place in row %d, column G.\n", j + 1);
        printf("Note that all numbers must be unique.\n");
        pw = scanf("%d", &num);
        for (int k = 0; k < 5; ++k) {
          if (game->boards[i].col_G[k] == num) {
            dup = true;
          }
        }
        if (num >= 46 && num <= 60 && !dup) {
          break;
        }
        printf("Invalid Entry\n");
        dup = false;
      }
      game->boards[i].col_G[j] = num;
    }
    for (int j = 0; j < 5; ++j) {
      int pw = 0;
      int num = 0;
      bool dup = false;
      while (true) {
        printf("Enter a number between 61 and 75 ");
        printf("to place in row %d, column O.\n", j + 1);
        printf("Note that all numbers must be unique.\n");
        pw = scanf("%d", &num);
        for (int k = 0; k < 5; ++k) {
          if (game->boards[i].col_O[k] == num) {
            dup = true;
          }
        }
        if (num >= 61 && num <= 75 && !dup) {
          break;
        }
        printf("Invalid Entry\n");
        dup = false;
      }
      game->boards[i].col_O[j] = num;
    }
  }
}


// print_boards(game) prints the boards in game.
// requires: game is not NULL

void print_boards(const struct game *game) {
  assert(game);
  printf("Here are the boards at current.\n");
  for (int i = 0; i < game->num_of_players; ++i) {
    printf("Player %d:\n", i + 1);
    printf(" B  I  N  G  O\n");
    for (int j = 0; j < 5; ++j) {
      if (game->boards[i].col_B[j] < 10) {
        printf(" ");
      }
      printf("%d ", game->boards[i].col_B[j]);
      if (game->boards[i].col_I[j] < 10) {
        printf(" ");
      }
      printf("%d ", game->boards[i].col_I[j]);
      if (game->boards[i].col_N[j] < 10) {
        printf(" ");
      }
      printf("%d ", game->boards[i].col_N[j]);
      if (game->boards[i].col_G[j] < 10) {
        printf(" ");
      }
      printf("%d ", game->boards[i].col_G[j]);
      if (game->boards[i].col_O[j] < 10) {
        printf(" ");
      }
      printf("%d\n", game->boards[i].col_O[j]);
    }
  }
  return;
}


// initialize_number_generator() initializes the random number generator using 
//   the time of day.

void initialize_number_generator(void) {
  srand((unsigned) time(NULL));
  return;
}


// new_secret_number() returns a randomly chosen number between 1 and 75.

int new_secret_number(void) {
  return rand() % 75 + 1;
}


// mark_boards(num, game) changes all of the spots in the game with num to 0.
// requires: game is not NULL
// effects: may modify game

void mark_boards(int num, struct game *game) {
  assert(game);
  if (num >= 1 && num <= 15) {
    for (int i = 0; i < game->num_of_players; ++i) {
      for (int j = 0; j < 5; ++j) {
        if (game->boards[i].col_B[j] == num) {
          game->boards[i].col_B[j] = 0;
        }
      }
    }
  } else if (num >= 16 && num <= 30) {
    for (int i = 0; i < game->num_of_players; ++i) {
      for (int j = 0; j < 5; ++j) {
        if (game->boards[i].col_I[j] == num) {
          game->boards[i].col_I[j] = 0;
        }
      }
    }
  } else if (num >= 31 && num <= 45) {
    for (int i = 0; i < game->num_of_players; ++i) {
      for (int j = 0; j < 5; ++j) {
        if (game->boards[i].col_N[j] == num) {
          game->boards[i].col_N[j] = 0;
        }
      }
    }
  } else if (num >= 46 && num <= 60) {
    for (int i = 0; i < game->num_of_players; ++i) {
      for (int j = 0; j < 5; ++j) {
        if (game->boards[i].col_G[j] == num) {
          game->boards[i].col_G[j] = 0;
        }
      }
    }
  } else if (num >= 61 && num <= 75) {
    for (int i = 0; i < game->num_of_players; ++i) {
      for (int j = 0; j < 5; ++j) {
        if (game->boards[i].col_O[j] == num) {
          game->boards[i].col_O[j] = 0;
        }
      }
    }
  }
  return;
}


// check_bingo(game) determines if anyone has 5 zeros in a row, column, or 
//   diagonal.
// requires: game is not NULL

void check_bingo(const struct game *game) {
  assert(game);
  for (int i = 0; i < game->num_of_players; ++i) {
    if (game->boards[i].col_B[0] == 0 && game->boards[i].col_B[1] == 0 && 
       game->boards[i].col_B[2] == 0 && game->boards[i].col_B[3] == 0 && 
       game->boards[i].col_B[4] == 0) {
      game->bingo[i] = true;
    }
  }
  for (int i = 0; i < game->num_of_players; ++i) {
    if (game->boards[i].col_I[0] == 0 && game->boards[i].col_I[1] == 0 && 
       game->boards[i].col_I[2] == 0 && game->boards[i].col_I[3] == 0 && 
       game->boards[i].col_I[4] == 0) {
      game->bingo[i] = true;
    }
  }
  for (int i = 0; i < game->num_of_players; ++i) {
    if (game->boards[i].col_N[0] == 0 && game->boards[i].col_N[1] == 0 && 
       game->boards[i].col_N[2] == 0 && game->boards[i].col_N[3] == 0 && 
       game->boards[i].col_N[4] == 0) {
      game->bingo[i] = true;
    }
  }
  for (int i = 0; i < game->num_of_players; ++i) {
    if (game->boards[i].col_G[0] == 0 && game->boards[i].col_G[1] == 0 && 
       game->boards[i].col_G[2] == 0 && game->boards[i].col_G[3] == 0 && 
       game->boards[i].col_G[4] == 0) {
      game->bingo[i] = true;
    }
  }
  for (int i = 0; i < game->num_of_players; ++i) {
    if (game->boards[i].col_O[0] == 0 && game->boards[i].col_O[1] == 0 && 
       game->boards[i].col_O[2] == 0 && game->boards[i].col_O[3] == 0 && 
       game->boards[i].col_O[4] == 0) {
      game->bingo[i] = true;
    }
  }
  for (int i = 0; i < game->num_of_players; ++i) {
    for (int j = 0; j < 5; ++j) {
      if (game->boards[i].col_B[j] == 0 && game->boards[i].col_I[j] == 0 && 
          game->boards[i].col_N[j] == 0 && game->boards[i].col_G[j] == 0 && 
          game->boards[i].col_O[j] == 0) {
        game->bingo[i] = true;
      }
    }
  }
  for (int i = 0; i < game->num_of_players; ++i) {
    if (game->boards[i].col_B[0] == 0 && game->boards[i].col_I[1] == 0 && 
        game->boards[i].col_N[2] == 0 && game->boards[i].col_G[3] == 0 && 
        game->boards[i].col_O[4] == 0) {
      game->bingo[i] = true;
    }
  }
  for (int i = 0; i < game->num_of_players; ++i) {
    if (game->boards[i].col_B[4] == 0 && game->boards[i].col_I[3] == 0 && 
        game->boards[i].col_N[2] == 0 && game->boards[i].col_G[1] == 0 && 
        game->boards[i].col_O[0] == 0) {
      game->bingo[i] = true;
    }
  }
  return;
}


// game_won(game) determines if anyone has won a game.
// requires: game is not NULL

bool game_won(const struct game *game) {
  assert(game);
  for (int i = 0; i < game->num_of_players; ++i) {
    if (game->bingo[i]) {
      return true;
    }
  }
  return false;
}


// play_bingo(game) plays BINGO, using the random number generator.
// requires: game is not NULL
// effects: modifies game

void play_bingo(struct game *game) {
  assert(game);
  printf("The first to score 5 in a row wins!\n");
  while (true) {
    int num = new_secret_number();
    if (num >= 1 && num <= 15) {
      printf("B%d\n", num);
    } else if (num >= 16 && num <= 30) {
      printf("I%d\n", num);
    } else if (num >= 31 && num <= 45) {
      printf("N%d\n", num);
    } else if (num >= 46 && num <= 60) {
      printf("G%d\n", num);
    } else if (num >= 61 && num <= 75) {
      printf("O%d\n", num);
    }
    mark_boards(num, game);
    print_boards(game);
    check_bingo(game);
    if (game_won(game)) {
      printf("BINGO!!\n");
      break;
    }
  }
  printf("The following player numbers have won:\n");
  for (int i = 0; i < game->num_of_players; ++i) {
    if (game->bingo[i]) {
      printf("%d\n", i + 1);
    }
  }
  return;
}


// destroy_game(game) frees the game.
// requires: players is not NULL
// effects: frees game (game no longer valid)

void destroy_game(struct game *game) {
  assert(game);
  free(game->boards);
  game->boards = NULL;
  free(game->bingo);
  game->bingo = NULL;
  free(game);
  game = NULL;
  return;
}


int main(void) {
  int num_of_players = number_of_players();
  struct game *g = initialize_game(num_of_players);
  initialize_boards(g);
  print_boards(g);
  play_bingo(g);
  destroy_game(g);
  return 0;
}
