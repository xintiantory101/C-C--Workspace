#include <assert.h>
#include <stdlib.h>
#include <time.h>


void initialize_number_generator(void) {
  srand((unsigned) time(NULL));
  return;
}


int new_secret_number(int min, int max) {
  assert(min <= max);
  return rand() % (max - min + 1) + min;
}