// This is a random number generation module!


// initialize_number_generator() initializes the number generator.

void initialize_number_generator(void);


// new_secret_number(min, max) generates a random number between min and max.
// requires: min <= max

int new_secret_number(int min, int max);