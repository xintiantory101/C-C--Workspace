// This program runs through Skunk.


#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "random.h"


// roll_dice() rolls 2 6-sided dice and adds them to the player's score if 
//   appropriate, as long as the player wishes
// effects: reads input
//          produces output
//          modifies p

void roll_dice(void) {
  initialize_number_generator();
  int rolls = 0;
  int points = 0;
  int roll1 = 0;
  int roll2 = 0;
  int pw = 0;
  char input = '\0';
  while (true) {
    roll1 = new_secret_number(1, 6);
    roll2 = new_secret_number(1, 6);
    printf("Your roll is %d + %d = %d.\n", roll1, roll2, roll1 + roll2);
    if (rolls > 0 && roll1 == roll2) {
      printf("Oh, no! You rolled a double!\n");
      points = 0;
      break;
    } else {
      points += (roll1 + roll2);
    }
    ++rolls;
    printf("Do you wish to continue playing?\n");
    printf("Enter 'Y' for yes or any other character for no.\n");
    pw = scanf(" %c", &input);
    if (pw != 1 || input != 'Y') {
      break;
    }
  }
  printf("Your final score is %d.\n", points);
  return;
}


int main(void) {
  printf("Welcome to Skunk!\n");
  printf("If a double is rolled, you lose all your points!\n");
  printf("Otherwise, you gain a number of points equal to the roll!\n");
  roll_dice();
  return 0;
}
