// Binomial Module


// factorial(n) determines the factorial of n.
// requires: n >= 0

int factorial(int n);


// binom_coeff(n, r) determines the binomial coefficient (n, r).
// requires: 0 <= r <= n

int binom_coeff(int n, int r);


// pascal_triangle(n) prints out Pascal's Triangle up to row n.
// requires: n >= 0
// effects: produces output

void pascal_triangle(int n);