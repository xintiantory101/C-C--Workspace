// This program runs a series of binomial-related functions!


#include <stdio.h>
#include "binomial.h"


int main(void) {
  pascal_triangle(12);
	return 0;
}
