#include <assert.h>
#include <stdio.h>
#include "binomial.h"


int factorial(int n) {
  assert(n >= 0);
  int num = 1;
  for (int i = 1; i <= n; ++i) {
    num *= i;
  }
  return num;
}


int binom_coeff(int n, int r) {
  assert(r >= 0);
  assert(n >= r);
  return factorial(n) / (factorial(r) * factorial(n - r));
}


void pascal_triangle(int n) {
  assert(n >= 0);
  for (int i = 0; i <= n; ++i) {
    for (int j = 0; j <= i; ++j) {
      printf("%d", binom_coeff(i, j));
      if (j < i) {
        printf(" ");
      }
    }
    printf("\n");
  }
  return;
}