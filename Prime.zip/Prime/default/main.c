#include <assert.h>
#include <stdbool.h>
#include <stdio.h>


// prime(n) determines if n is prime.
// time: O(n)

bool prime(int n) {
  assert(n >= 2);
  for (int i = 2; i < n; ++i) {
    if (n % i == 0) {
      return false;
    }
  }
  return true;
}


int main(void) {
  assert(prime(101));
  assert(!prime(105));
	return 0;
}
